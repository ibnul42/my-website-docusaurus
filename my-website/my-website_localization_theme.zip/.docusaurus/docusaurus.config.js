export default {
  "title": "Welcome",
  "tagline": "My Website",
  "url": "https://kind-murdock-987e6d.netlify.app/",
  "baseUrl": "/",
  "onBrokenLinks": "throw",
  "onBrokenMarkdownLinks": "warn",
  "favicon": "img/favicon.ico",
  "organizationName": "my-website-docusaurus",
  "projectName": "my-website-docusaurus",
  "presets": [
    [
      "classic",
      {
        "docs": {
          "sidebarPath": "D:\\Fiverrr\\borhanusa\\my-website-docusaurus\\my-website\\sidebars.js",
          "editUrl": "https://github.com/facebook/docusaurus/tree/main/packages/create-docusaurus/templates/shared/"
        },
        "blog": {
          "showReadingTime": true,
          "editUrl": "https://github.com/facebook/docusaurus/tree/main/packages/create-docusaurus/templates/shared/"
        },
        "theme": {
          "customCss": "D:\\Fiverrr\\borhanusa\\my-website-docusaurus\\my-website\\src\\css\\custom.css"
        }
      }
    ]
  ],
  "plugins": [
    [
      "D:\\Fiverrr\\borhanusa\\my-website-docusaurus\\my-website\\node_modules\\@easyops-cn\\docusaurus-search-local\\dist\\server\\server\\index.js",
      {
        "hashed": true
      }
    ],
    [
      "@docusaurus/plugin-content-docs",
      {
        "id": "programming",
        "path": "programming",
        "routeBasePath": "programming",
        "sidebarPath": "D:\\Fiverrr\\borhanusa\\my-website-docusaurus\\my-website\\programming.js"
      }
    ],
    [
      "@docusaurus/plugin-content-docs",
      {
        "id": "cloud",
        "path": "cloud",
        "routeBasePath": "cloud",
        "sidebarPath": "D:\\Fiverrr\\borhanusa\\my-website-docusaurus\\my-website\\cloud.js"
      }
    ],
    [
      "@docusaurus/plugin-content-docs",
      {
        "id": "devops",
        "path": "devops",
        "routeBasePath": "devops",
        "sidebarPath": "D:\\Fiverrr\\borhanusa\\my-website-docusaurus\\my-website\\devops.js"
      }
    ]
  ],
  "themeConfig": {
    "navbar": {
      "title": "My Site",
      "logo": {
        "alt": "My Site Logo",
        "src": "img/logo.png"
      },
      "items": [
        {
          "type": "doc",
          "docId": "intro",
          "position": "left",
          "label": "Tutorial"
        },
        {
          "to": "/programming/intro",
          "label": "Programming",
          "position": "left"
        },
        {
          "to": "/cloud/intro",
          "label": "Cloud",
          "position": "left"
        },
        {
          "to": "/devops/intro",
          "label": "DevOps",
          "position": "left"
        },
        {
          "to": "/getting-started",
          "label": "Getting Started",
          "position": "right"
        },
        {
          "to": "/blog",
          "label": "Blog",
          "position": "right"
        },
        {
          "href": "https://github.com/ibnul42/my-website-docusaurus",
          "label": "GitHub",
          "position": "right"
        }
      ],
      "hideOnScroll": false
    },
    "footer": {
      "style": "dark",
      "links": [
        {
          "title": "Learn",
          "items": [
            {
              "label": "Docs",
              "to": "/docs/intro"
            },
            {
              "label": "Programming",
              "to": "/programming/intro"
            },
            {
              "label": "Cloud",
              "to": "/cloud/intro"
            },
            {
              "label": "DevOps",
              "to": "/devops/intro"
            }
          ]
        },
        {
          "title": "Find Us",
          "items": [
            {
              "label": "Blog",
              "to": "/blog"
            },
            {
              "label": "Twitter",
              "href": "https://twitter.com/"
            },
            {
              "label": "Github",
              "href": "https://github.com/"
            },
            {
              "label": "Stack Overflow",
              "href": "https://stackoverflow.com/"
            }
          ]
        },
        {
          "title": "More",
          "items": [
            {
              "label": "Privacy",
              "to": "/privacy"
            },
            {
              "label": "Terms of Services",
              "to": "/terms-of-services"
            },
            {
              "label": "Contributor",
              "to": "/contributor"
            }
          ]
        }
      ],
      "copyright": "Copyright © 2021 my-website"
    },
    "prism": {
      "theme": {
        "plain": {
          "color": "#bfc7d5",
          "backgroundColor": "#292d3e"
        },
        "styles": [
          {
            "types": [
              "comment"
            ],
            "style": {
              "color": "rgb(105, 112, 152)",
              "fontStyle": "italic"
            }
          },
          {
            "types": [
              "string",
              "inserted"
            ],
            "style": {
              "color": "rgb(195, 232, 141)"
            }
          },
          {
            "types": [
              "number"
            ],
            "style": {
              "color": "rgb(247, 140, 108)"
            }
          },
          {
            "types": [
              "builtin",
              "char",
              "constant",
              "function"
            ],
            "style": {
              "color": "rgb(130, 170, 255)"
            }
          },
          {
            "types": [
              "punctuation",
              "selector"
            ],
            "style": {
              "color": "rgb(199, 146, 234)"
            }
          },
          {
            "types": [
              "variable"
            ],
            "style": {
              "color": "rgb(191, 199, 213)"
            }
          },
          {
            "types": [
              "class-name",
              "attr-name"
            ],
            "style": {
              "color": "rgb(255, 203, 107)"
            }
          },
          {
            "types": [
              "tag",
              "deleted"
            ],
            "style": {
              "color": "rgb(255, 85, 114)"
            }
          },
          {
            "types": [
              "operator"
            ],
            "style": {
              "color": "rgb(137, 221, 255)"
            }
          },
          {
            "types": [
              "boolean"
            ],
            "style": {
              "color": "rgb(255, 88, 116)"
            }
          },
          {
            "types": [
              "keyword"
            ],
            "style": {
              "fontStyle": "italic"
            }
          },
          {
            "types": [
              "doctype"
            ],
            "style": {
              "color": "rgb(199, 146, 234)",
              "fontStyle": "italic"
            }
          },
          {
            "types": [
              "namespace"
            ],
            "style": {
              "color": "rgb(178, 204, 214)"
            }
          },
          {
            "types": [
              "url"
            ],
            "style": {
              "color": "rgb(221, 221, 221)"
            }
          }
        ]
      },
      "darkTheme": {
        "plain": {
          "color": "#bfc7d5",
          "backgroundColor": "#292d3e"
        },
        "styles": [
          {
            "types": [
              "comment"
            ],
            "style": {
              "color": "rgb(105, 112, 152)",
              "fontStyle": "italic"
            }
          },
          {
            "types": [
              "string",
              "inserted"
            ],
            "style": {
              "color": "rgb(195, 232, 141)"
            }
          },
          {
            "types": [
              "number"
            ],
            "style": {
              "color": "rgb(247, 140, 108)"
            }
          },
          {
            "types": [
              "builtin",
              "char",
              "constant",
              "function"
            ],
            "style": {
              "color": "rgb(130, 170, 255)"
            }
          },
          {
            "types": [
              "punctuation",
              "selector"
            ],
            "style": {
              "color": "rgb(199, 146, 234)"
            }
          },
          {
            "types": [
              "variable"
            ],
            "style": {
              "color": "rgb(191, 199, 213)"
            }
          },
          {
            "types": [
              "class-name",
              "attr-name"
            ],
            "style": {
              "color": "rgb(255, 203, 107)"
            }
          },
          {
            "types": [
              "tag",
              "deleted"
            ],
            "style": {
              "color": "rgb(255, 85, 114)"
            }
          },
          {
            "types": [
              "operator"
            ],
            "style": {
              "color": "rgb(137, 221, 255)"
            }
          },
          {
            "types": [
              "boolean"
            ],
            "style": {
              "color": "rgb(255, 88, 116)"
            }
          },
          {
            "types": [
              "keyword"
            ],
            "style": {
              "fontStyle": "italic"
            }
          },
          {
            "types": [
              "doctype"
            ],
            "style": {
              "color": "rgb(199, 146, 234)",
              "fontStyle": "italic"
            }
          },
          {
            "types": [
              "namespace"
            ],
            "style": {
              "color": "rgb(178, 204, 214)"
            }
          },
          {
            "types": [
              "url"
            ],
            "style": {
              "color": "rgb(221, 221, 221)"
            }
          }
        ]
      },
      "additionalLanguages": []
    },
    "colorMode": {
      "defaultMode": "light",
      "disableSwitch": false,
      "respectPrefersColorScheme": false,
      "switchConfig": {
        "darkIcon": "🌜",
        "darkIconStyle": {},
        "lightIcon": "🌞",
        "lightIconStyle": {}
      }
    },
    "docs": {
      "versionPersistence": "localStorage"
    },
    "metadata": [],
    "hideableSidebar": false,
    "tableOfContents": {
      "minHeadingLevel": 2,
      "maxHeadingLevel": 3
    }
  },
  "baseUrlIssueBanner": true,
  "i18n": {
    "defaultLocale": "en",
    "locales": [
      "en"
    ],
    "localeConfigs": {}
  },
  "onDuplicateRoutes": "warn",
  "staticDirectories": [
    "static"
  ],
  "customFields": {},
  "themes": [],
  "titleDelimiter": "|",
  "noIndex": false
};