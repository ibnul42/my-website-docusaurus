export default [
  require("D:\\Fiverrr\\borhanusa\\my-website-docusaurus\\my-website\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("D:\\Fiverrr\\borhanusa\\my-website-docusaurus\\my-website\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("D:\\Fiverrr\\borhanusa\\my-website-docusaurus\\my-website\\node_modules\\@docusaurus\\theme-classic\\lib\\admonitions.css"),
  require("D:\\Fiverrr\\borhanusa\\my-website-docusaurus\\my-website\\src\\css\\custom.css"),
];
