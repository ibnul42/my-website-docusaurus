
import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/blog',
    component: ComponentCreator('/blog','520'),
    exact: true
  },
  {
    path: '/blog/archive',
    component: ComponentCreator('/blog/archive','f4c'),
    exact: true
  },
  {
    path: '/blog/first-blog-post',
    component: ComponentCreator('/blog/first-blog-post','6c7'),
    exact: true
  },
  {
    path: '/blog/long-blog-post',
    component: ComponentCreator('/blog/long-blog-post','f06'),
    exact: true
  },
  {
    path: '/blog/mdx-blog-post',
    component: ComponentCreator('/blog/mdx-blog-post','bee'),
    exact: true
  },
  {
    path: '/blog/tags',
    component: ComponentCreator('/blog/tags','e13'),
    exact: true
  },
  {
    path: '/blog/tags/docusaurus',
    component: ComponentCreator('/blog/tags/docusaurus','ddf'),
    exact: true
  },
  {
    path: '/blog/tags/facebook',
    component: ComponentCreator('/blog/tags/facebook','ede'),
    exact: true
  },
  {
    path: '/blog/tags/hello',
    component: ComponentCreator('/blog/tags/hello','4c2'),
    exact: true
  },
  {
    path: '/blog/tags/hola',
    component: ComponentCreator('/blog/tags/hola','752'),
    exact: true
  },
  {
    path: '/blog/welcome',
    component: ComponentCreator('/blog/welcome','bfa'),
    exact: true
  },
  {
    path: '/contributor',
    component: ComponentCreator('/contributor','4c4'),
    exact: true
  },
  {
    path: '/getting-started',
    component: ComponentCreator('/getting-started','696'),
    exact: true
  },
  {
    path: '/markdown-page',
    component: ComponentCreator('/markdown-page','be1'),
    exact: true
  },
  {
    path: '/privacy',
    component: ComponentCreator('/privacy','b45'),
    exact: true
  },
  {
    path: '/search',
    component: ComponentCreator('/search','79a'),
    exact: true
  },
  {
    path: '/terms-of-services',
    component: ComponentCreator('/terms-of-services','568'),
    exact: true
  },
  {
    path: '/cloud',
    component: ComponentCreator('/cloud','a98'),
    routes: [
      {
        path: '/cloud/aws/intro',
        component: ComponentCreator('/cloud/aws/intro','bec'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/aws/tutorial-basics/congratulations',
        component: ComponentCreator('/cloud/aws/tutorial-basics/congratulations','272'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/aws/tutorial-basics/create-a-blog-post',
        component: ComponentCreator('/cloud/aws/tutorial-basics/create-a-blog-post','e49'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/aws/tutorial-basics/create-a-document',
        component: ComponentCreator('/cloud/aws/tutorial-basics/create-a-document','bd5'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/aws/tutorial-basics/create-a-page',
        component: ComponentCreator('/cloud/aws/tutorial-basics/create-a-page','4be'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/aws/tutorial-basics/deploy-your-site',
        component: ComponentCreator('/cloud/aws/tutorial-basics/deploy-your-site','572'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/aws/tutorial-basics/markdown-features',
        component: ComponentCreator('/cloud/aws/tutorial-basics/markdown-features','25f'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/aws/tutorial-extras/manage-docs-versions',
        component: ComponentCreator('/cloud/aws/tutorial-extras/manage-docs-versions','510'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/aws/tutorial-extras/translate-your-site',
        component: ComponentCreator('/cloud/aws/tutorial-extras/translate-your-site','a5a'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/azure/intro',
        component: ComponentCreator('/cloud/azure/intro','d06'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/azure/tutorial-basics/congratulations',
        component: ComponentCreator('/cloud/azure/tutorial-basics/congratulations','7b7'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/azure/tutorial-basics/create-a-blog-post',
        component: ComponentCreator('/cloud/azure/tutorial-basics/create-a-blog-post','34f'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/azure/tutorial-basics/create-a-document',
        component: ComponentCreator('/cloud/azure/tutorial-basics/create-a-document','442'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/azure/tutorial-basics/create-a-page',
        component: ComponentCreator('/cloud/azure/tutorial-basics/create-a-page','1e6'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/azure/tutorial-basics/deploy-your-site',
        component: ComponentCreator('/cloud/azure/tutorial-basics/deploy-your-site','82a'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/azure/tutorial-basics/markdown-features',
        component: ComponentCreator('/cloud/azure/tutorial-basics/markdown-features','30f'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/azure/tutorial-extras/manage-docs-versions',
        component: ComponentCreator('/cloud/azure/tutorial-extras/manage-docs-versions','2fc'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/azure/tutorial-extras/translate-your-site',
        component: ComponentCreator('/cloud/azure/tutorial-extras/translate-your-site','b87'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/google/intro',
        component: ComponentCreator('/cloud/google/intro','2de'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/google/tutorial-basics/congratulations',
        component: ComponentCreator('/cloud/google/tutorial-basics/congratulations','942'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/google/tutorial-basics/create-a-blog-post',
        component: ComponentCreator('/cloud/google/tutorial-basics/create-a-blog-post','26e'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/google/tutorial-basics/create-a-document',
        component: ComponentCreator('/cloud/google/tutorial-basics/create-a-document','6e2'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/google/tutorial-basics/create-a-page',
        component: ComponentCreator('/cloud/google/tutorial-basics/create-a-page','db6'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/google/tutorial-basics/deploy-your-site',
        component: ComponentCreator('/cloud/google/tutorial-basics/deploy-your-site','f72'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/google/tutorial-basics/markdown-features',
        component: ComponentCreator('/cloud/google/tutorial-basics/markdown-features','ff2'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/google/tutorial-extras/manage-docs-versions',
        component: ComponentCreator('/cloud/google/tutorial-extras/manage-docs-versions','471'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/google/tutorial-extras/translate-your-site',
        component: ComponentCreator('/cloud/google/tutorial-extras/translate-your-site','0ac'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/cloud/intro',
        component: ComponentCreator('/cloud/intro','a17'),
        exact: true,
        'sidebar': "tutorialSidebar"
      }
    ]
  },
  {
    path: '/devops',
    component: ComponentCreator('/devops','f36'),
    routes: [
      {
        path: '/devops/configure/intro',
        component: ComponentCreator('/devops/configure/intro','b5f'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/configure/tutorial-basics/congratulations',
        component: ComponentCreator('/devops/configure/tutorial-basics/congratulations','621'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/configure/tutorial-basics/create-a-blog-post',
        component: ComponentCreator('/devops/configure/tutorial-basics/create-a-blog-post','da9'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/configure/tutorial-basics/create-a-document',
        component: ComponentCreator('/devops/configure/tutorial-basics/create-a-document','04f'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/configure/tutorial-basics/create-a-page',
        component: ComponentCreator('/devops/configure/tutorial-basics/create-a-page','8e8'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/configure/tutorial-basics/deploy-your-site',
        component: ComponentCreator('/devops/configure/tutorial-basics/deploy-your-site','258'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/configure/tutorial-basics/markdown-features',
        component: ComponentCreator('/devops/configure/tutorial-basics/markdown-features','41b'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/configure/tutorial-extras/manage-docs-versions',
        component: ComponentCreator('/devops/configure/tutorial-extras/manage-docs-versions','bf8'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/configure/tutorial-extras/translate-your-site',
        component: ComponentCreator('/devops/configure/tutorial-extras/translate-your-site','961'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/integration/intro',
        component: ComponentCreator('/devops/integration/intro','847'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/integration/tutorial-basics/congratulations',
        component: ComponentCreator('/devops/integration/tutorial-basics/congratulations','f1b'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/integration/tutorial-basics/create-a-blog-post',
        component: ComponentCreator('/devops/integration/tutorial-basics/create-a-blog-post','8fb'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/integration/tutorial-basics/create-a-document',
        component: ComponentCreator('/devops/integration/tutorial-basics/create-a-document','5b1'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/integration/tutorial-basics/create-a-page',
        component: ComponentCreator('/devops/integration/tutorial-basics/create-a-page','775'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/integration/tutorial-basics/deploy-your-site',
        component: ComponentCreator('/devops/integration/tutorial-basics/deploy-your-site','345'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/integration/tutorial-basics/markdown-features',
        component: ComponentCreator('/devops/integration/tutorial-basics/markdown-features','9d6'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/integration/tutorial-extras/manage-docs-versions',
        component: ComponentCreator('/devops/integration/tutorial-extras/manage-docs-versions','e02'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/integration/tutorial-extras/translate-your-site',
        component: ComponentCreator('/devops/integration/tutorial-extras/translate-your-site','b14'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/intro',
        component: ComponentCreator('/devops/intro','f5c'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/testing/intro',
        component: ComponentCreator('/devops/testing/intro','948'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/testing/tutorial-basics/congratulations',
        component: ComponentCreator('/devops/testing/tutorial-basics/congratulations','236'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/testing/tutorial-basics/create-a-blog-post',
        component: ComponentCreator('/devops/testing/tutorial-basics/create-a-blog-post','aa8'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/testing/tutorial-basics/create-a-document',
        component: ComponentCreator('/devops/testing/tutorial-basics/create-a-document','e24'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/testing/tutorial-basics/create-a-page',
        component: ComponentCreator('/devops/testing/tutorial-basics/create-a-page','57e'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/testing/tutorial-basics/deploy-your-site',
        component: ComponentCreator('/devops/testing/tutorial-basics/deploy-your-site','ac8'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/testing/tutorial-basics/markdown-features',
        component: ComponentCreator('/devops/testing/tutorial-basics/markdown-features','4ab'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/testing/tutorial-extras/manage-docs-versions',
        component: ComponentCreator('/devops/testing/tutorial-extras/manage-docs-versions','1b3'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/devops/testing/tutorial-extras/translate-your-site',
        component: ComponentCreator('/devops/testing/tutorial-extras/translate-your-site','2df'),
        exact: true,
        'sidebar': "tutorialSidebar"
      }
    ]
  },
  {
    path: '/docs',
    component: ComponentCreator('/docs','ccd'),
    routes: [
      {
        path: '/docs/intro',
        component: ComponentCreator('/docs/intro','aed'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-01/desc',
        component: ComponentCreator('/docs/tutorial-01/desc','17b'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-01/tutorial01',
        component: ComponentCreator('/docs/tutorial-01/tutorial01','df0'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/congratulations',
        component: ComponentCreator('/docs/tutorial-basics/congratulations','793'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/create-a-blog-post',
        component: ComponentCreator('/docs/tutorial-basics/create-a-blog-post','68e'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/create-a-document',
        component: ComponentCreator('/docs/tutorial-basics/create-a-document','c2d'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/create-a-page',
        component: ComponentCreator('/docs/tutorial-basics/create-a-page','f44'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/deploy-your-site',
        component: ComponentCreator('/docs/tutorial-basics/deploy-your-site','e46'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/markdown-features',
        component: ComponentCreator('/docs/tutorial-basics/markdown-features','4b7'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-extras/manage-docs-versions',
        component: ComponentCreator('/docs/tutorial-extras/manage-docs-versions','fdd'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-extras/translate-your-site',
        component: ComponentCreator('/docs/tutorial-extras/translate-your-site','2d7'),
        exact: true,
        'sidebar': "tutorialSidebar"
      }
    ]
  },
  {
    path: '/programming',
    component: ComponentCreator('/programming','070'),
    routes: [
      {
        path: '/programming/intro',
        component: ComponentCreator('/programming/intro','c52'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/javascript/intro',
        component: ComponentCreator('/programming/javascript/intro','4ad'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/javascript/tutorial-basics/congratulations',
        component: ComponentCreator('/programming/javascript/tutorial-basics/congratulations','ef0'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/javascript/tutorial-basics/create-a-blog-post',
        component: ComponentCreator('/programming/javascript/tutorial-basics/create-a-blog-post','6c3'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/javascript/tutorial-basics/create-a-document',
        component: ComponentCreator('/programming/javascript/tutorial-basics/create-a-document','a31'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/javascript/tutorial-basics/create-a-page',
        component: ComponentCreator('/programming/javascript/tutorial-basics/create-a-page','dc7'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/javascript/tutorial-basics/deploy-your-site',
        component: ComponentCreator('/programming/javascript/tutorial-basics/deploy-your-site','396'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/javascript/tutorial-basics/markdown-features',
        component: ComponentCreator('/programming/javascript/tutorial-basics/markdown-features','80b'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/javascript/tutorial-extras/manage-docs-versions',
        component: ComponentCreator('/programming/javascript/tutorial-extras/manage-docs-versions','e1d'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/javascript/tutorial-extras/translate-your-site',
        component: ComponentCreator('/programming/javascript/tutorial-extras/translate-your-site','a94'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/python/intro',
        component: ComponentCreator('/programming/python/intro','3f7'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/python/tutorial-basics/congratulations',
        component: ComponentCreator('/programming/python/tutorial-basics/congratulations','3da'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/python/tutorial-basics/create-a-blog-post',
        component: ComponentCreator('/programming/python/tutorial-basics/create-a-blog-post','919'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/python/tutorial-basics/create-a-document',
        component: ComponentCreator('/programming/python/tutorial-basics/create-a-document','127'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/python/tutorial-basics/create-a-page',
        component: ComponentCreator('/programming/python/tutorial-basics/create-a-page','a56'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/python/tutorial-basics/deploy-your-site',
        component: ComponentCreator('/programming/python/tutorial-basics/deploy-your-site','c6f'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/python/tutorial-basics/markdown-features',
        component: ComponentCreator('/programming/python/tutorial-basics/markdown-features','1a3'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/python/tutorial-extras/manage-docs-versions',
        component: ComponentCreator('/programming/python/tutorial-extras/manage-docs-versions','a70'),
        exact: true,
        'sidebar': "tutorialSidebar"
      },
      {
        path: '/programming/python/tutorial-extras/translate-your-site',
        component: ComponentCreator('/programming/python/tutorial-extras/translate-your-site','08e'),
        exact: true,
        'sidebar': "tutorialSidebar"
      }
    ]
  },
  {
    path: '/',
    component: ComponentCreator('/','deb'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*')
  }
];
