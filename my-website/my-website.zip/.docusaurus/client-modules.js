export default [
  require("C:\\Users\\ibnul\\Desktop\\my-website-docusaurus\\my-website\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Users\\ibnul\\Desktop\\my-website-docusaurus\\my-website\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Users\\ibnul\\Desktop\\my-website-docusaurus\\my-website\\node_modules\\@docusaurus\\theme-classic\\lib\\admonitions.css"),
  require("C:\\Users\\ibnul\\Desktop\\my-website-docusaurus\\my-website\\src\\css\\custom.css"),
];
