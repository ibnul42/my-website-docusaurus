import React from 'react';
import Layout from '@theme/Layout';

export default function MyReactPage() {
  return (
    <Layout>
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <h1>This is Privacy page</h1>
      </div>
    </Layout>
  );
}